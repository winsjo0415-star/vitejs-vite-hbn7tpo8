// Modal component for launching and playing games

import { Dialog, DialogContent } from './ui/dialog';
import { Button } from './ui/button';
import { X, Maximize2, Minimize2 } from 'lucide-react';
import { Game } from '../lib/types';
import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface GameLauncherProps {
  game: Game | null;
  open: boolean;
  onClose: () => void;
}

export function GameLauncher({ game, open, onClose }: GameLauncherProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    if (open && game) {
      setIsLoading(true);
      // Simulate loading time
      const timer = setTimeout(() => setIsLoading(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [open, game]);

  useEffect(() => {
    if (open && game && !isLoading && iframeRef.current) {
      // Find the main HTML file
      const htmlFile = game.files.find(f => f.type === 'html');
      
      if (htmlFile) {
        // Create a blob URL with the HTML content
        const blob = new Blob([htmlFile.content], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        iframeRef.current.src = url;

        return () => {
          URL.revokeObjectURL(url);
        };
      }
    }
  }, [game, open, isLoading]);

  if (!game) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent
        className={`p-0 gap-0 ${
          isFullscreen ? 'max-w-full w-screen h-screen' : 'max-w-6xl w-full h-[85vh]'
        } transition-all duration-300`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-background/95 backdrop-blur-sm">
          <div>
            <h2 className="font-semibold">{game.title}</h2>
            <p className="text-sm text-muted-foreground">{game.description}</p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsFullscreen(!isFullscreen)}
            >
              {isFullscreen ? (
                <Minimize2 className="h-4 w-4" />
              ) : (
                <Maximize2 className="h-4 w-4" />
              )}
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Game container */}
        <div className="relative flex-1 bg-black">
          <AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-sm z-10"
              >
                <div className="text-center space-y-4">
                  <div className="relative">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                      className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full"
                    />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Loading Game...</h3>
                    <p className="text-sm text-muted-foreground">Please wait</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <iframe
            ref={iframeRef}
            className="w-full h-full border-0"
            title={game.title}
            sandbox="allow-scripts allow-same-origin allow-forms"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
