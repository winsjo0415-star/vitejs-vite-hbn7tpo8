// LocalStorage utilities for game library

import { Game, GameFile } from './types';

const STORAGE_KEY = 'game-library-data';

// Get all games from localStorage
export function getGames(): Game[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error reading games from storage:', error);
    return [];
  }
}

// Save games to localStorage
export function saveGames(games: Game[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(games));
  } catch (error) {
    console.error('Error saving games to storage:', error);
  }
}

// Add a new game
export function addGame(game: Game): void {
  const games = getGames();
  games.push(game);
  saveGames(games);
}

// Update an existing game
export function updateGame(gameId: string, updates: Partial<Game>): void {
  const games = getGames();
  const index = games.findIndex(g => g.id === gameId);
  if (index !== -1) {
    games[index] = { ...games[index], ...updates };
    saveGames(games);
  }
}

// Delete a game
export function deleteGame(gameId: string): void {
  const games = getGames();
  const filtered = games.filter(g => g.id !== gameId);
  saveGames(filtered);
}

// Toggle favorite status
export function toggleFavorite(gameId: string): void {
  const games = getGames();
  const index = games.findIndex(g => g.id === gameId);
  if (index !== -1) {
    games[index].isFavorite = !games[index].isFavorite;
    saveGames(games);
  }
}

// Update last played timestamp
export function updateLastPlayed(gameId: string): void {
  updateGame(gameId, { lastPlayed: Date.now() });
}

// Generate a unique ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Read file as text
export function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsText(file);
  });
}
